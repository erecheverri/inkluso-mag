# Inkluso Magazine Runbook

This runbook walks you through starting a new issue of **Inkluso Magazine** using the files and workflows in this repository.  Follow each step carefully; where necessary, you will need to perform actions in the GitHub web interface (e.g. creating secrets, triggering workflows, merging pull requests).

## 1. Create the repository

1. Go to <https://github.com/new> and create a new repository named `inkluso-mag` under your account (or another name of your choosing).
2. Leave it public unless you have specific privacy requirements.
3. Do **not** initialize with a README or .gitignore—the content will be uploaded in the next step.
4. Once created, open your new repository.

## 2. Import the scaffold

You can import the scaffold by uploading the contents of this directory via the GitHub UI:

1. On your repository page, click **Add file → Upload files**.
2. Drag and drop the entire contents of the `inkluso-mag` folder (from this scaffold) into the upload area.  Be sure the folder structure is preserved.
3. Scroll down and commit the upload directly to the `main` branch.

Alternatively, you can clone the repository and push via Git, but the upload method is simplest for a fresh start.

## 3. Set up secrets

1. Navigate to **Settings → Secrets → Actions**.
2. Click **New repository secret** for each of the following:
   - `OPENAI_API_KEY`: your OpenAI API key.
   - `OPENAI_MODEL`: the model name to use, e.g. `gpt-5-reasoning`.
3. (Optional) When your own agents go live, add secrets for `XTKA_URL`, `LOTI_URL`, `SIG1_URL`, `GOBLINO_URL`, `GMTK_URL`, and their respective API keys.

These secrets are required for the pipeline to call OpenAI’s Agent Mode and your own services.

## 4. Create a brief

Briefs live in the `content/briefs` directory.  They are YAML files that declare the issue date and the articles you’d like to produce.  Use the sample file `2025-11-issue.yml` as a template.  For example:

```yaml
issue: "2025-12"
articles:
  - slug: "editorial"
    title_hint: "The future of local-first"
    bullets:
      - "Why data sovereignty matters"
      - "Practical steps for communities"
  - slug: "roundtable"
    title_hint: "Voices from the network"
    bullets:
      - "Experiences with local-first apps"
      - "Challenges and opportunities"
```

Commit your brief file to the `main` branch before running the pipeline.

## 5. Run the Agents Pipeline

1. Go to the **Actions** tab of your repository.
2. Click on **Inkluso Agents Pipeline**.
3. Click **Run workflow** and, if needed, specify the path to your brief (e.g. `content/briefs/2025-12-issue.yml`).
4. Wait for the workflow to complete; it will create a new branch and a pull request against the `dev` branch containing the generated drafts.

## 6. Review and merge the drafts

1. Navigate to the **Pull requests** tab.  You should see a pull request titled *Inkluso Agents Pipeline output*.
2. Review the generated drafts in `content/drafts/<issue>/<slug>/draft.md`.
3. If you need to edit or polish the drafts, push commits to the draft branch.
4. Merge the pull request into the `dev` branch once you’re satisfied.

## 7. Publish the issue

1. Create a pull request from `dev` into `main` (you can do this manually via GitHub’s interface).
2. Merge the pull request into `main`.
3. The **Build and Deploy** workflow will run automatically.  It builds the static site into the `site` directory, deploys to GitHub Pages, and compiles all drafts into a single PDF (uploaded as an artifact).

Your issue is now live on GitHub Pages!

## Troubleshooting

- **Pipeline fails because `OPENAI_API_KEY` is not set**: Make sure you added the secret in **Settings → Secrets → Actions**.
- **No drafts generated**: Confirm that your brief file is correctly formatted YAML and that you specified the correct path when triggering the workflow.
- **PDF not generated**: If no drafts exist under `content/drafts/<issue>`, pandoc will skip the PDF build.  Ensure that drafts were generated and committed before merging to `main`.

Feel free to modify or extend this runbook as your process evolves.